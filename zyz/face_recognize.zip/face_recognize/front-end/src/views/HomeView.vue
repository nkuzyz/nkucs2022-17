<template>
  <div style="width: 100%">
    <!--静态html资源-->

    <div>
      <iframe
        src="http://127.0.0.1:5002"
        scrolling="auto"
        frameborder="0"
        style="width: 100%; height: 900px"
      ></iframe>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {},
  created() {},
};
</script>
